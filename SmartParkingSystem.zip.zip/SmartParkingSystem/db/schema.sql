-- =========================================================
-- UNIVERSITY MINI-PROJECT: SMART PARKING SYSTEM DATABASE SCHEMA
-- =========================================================

-- 1. Create and Initialize the Database Workspace Environment
CREATE DATABASE IF NOT EXISTS smart_parking_db;
USE smart_parking_db;

-- 2. Create the Infrastructure Asset Tracker Table (Independent Table)
CREATE TABLE IF NOT EXISTS parking_spots (
    spot_id INT AUTO_INCREMENT PRIMARY KEY,
    spot_number VARCHAR(10) NOT NULL UNIQUE,
    spot_type VARCHAR(20) NOT NULL, -- Compact, Large, EV
    is_available BOOLEAN DEFAULT TRUE
);

-- 3. Create the Vehicle Allocation Logs Table (Dependent Table with Foreign Key)
CREATE TABLE IF NOT EXISTS vehicles (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_number VARCHAR(20) NOT NULL UNIQUE,
    vehicle_type VARCHAR(20) NOT NULL,
    owner_name VARCHAR(50) NOT NULL,
    allocated_spot_id INT,
    entry_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (allocated_spot_id) REFERENCES parking_spots(spot_id) ON DELETE SET NULL
);

-- 4. Seed Initial Physical Parking Slots into the Database
INSERT INTO parking_spots (spot_number, spot_type, is_available) VALUES 
('A-101', 'Compact', TRUE),
('A-102', 'Compact', TRUE),
('B-201', 'Large', TRUE),
('B-202', 'Large', TRUE),
('E-301', 'EV', TRUE);