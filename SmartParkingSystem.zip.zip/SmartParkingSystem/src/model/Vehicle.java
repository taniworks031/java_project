package model;

import java.sql.Timestamp;

/**
 * Represents the Vehicle entity entering the ecosystem.
 * Maps directly to the 'vehicles' table in MySQL.
 * Demonstrates: OOP Encapsulation and Data Mapping.
 */
public class Vehicle {
    private int vehicleId;
    private String vehicleNumber;
    private String vehicleType;
    private String ownerName;
    private int allocatedSpotId; // Serves as the Foreign Key mapping element
    private Timestamp entryTime;

    // 1. Default No-Argument Constructor
    public Vehicle() {}

    // 2. Parameterized Constructor used during vehicle intake operations
    public Vehicle(String vehicleNumber, String vehicleType, String ownerName, int allocatedSpotId) {
        this.vehicleNumber = vehicleNumber;
        this.vehicleType = vehicleType;
        this.ownerName = ownerName;
        this.allocatedSpotId = allocatedSpotId;
    }

    // 3. Getters and Setters
    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public int getAllocatedSpotId() {
        return allocatedSpotId;
    }

    public void setAllocatedSpotId(int allocatedSpotId) {
        this.allocatedSpotId = allocatedSpotId;
    }

    public Timestamp getEntryTime() {
        return entryTime;
    }

    public void setEntryTime(Timestamp entryTime) {
        this.entryTime = entryTime;
    }
}