package model;

/**
 * Represents the physical Parking Spot entity.
 * Maps directly to the 'parking_spots' table in MySQL.
 * Demonstrates: OOP Encapsulation.
 */
public class ParkingSpot {
    // Private variables prevent direct outside modification (Data Hiding)
    private int spotId;
    private String spotNumber;
    private String spotType;
    private boolean isAvailable;

    // 1. Default No-Argument Constructor (Required for enterprise patterns)
    public ParkingSpot() {}

    // 2. Parameterized Constructor to quickly create spot instances
    public ParkingSpot(int spotId, String spotNumber, String spotType, boolean isAvailable) {
        this.spotId = spotId;
        this.spotNumber = spotNumber;
        this.spotType = spotType;
        this.isAvailable = isAvailable;
    }

    // 3. Getters and Setters (Public accessors to encapsulated data fields)
    public int getSpotId() {
        return spotId;
    }

    public void setSpotId(int spotId) {
        this.spotId = spotId;
    }

    public String getSpotNumber() {
        return spotNumber;
    }

    public void setSpotNumber(String spotNumber) {
        this.spotNumber = spotNumber;
    }

    public String getSpotType() {
        return spotType;
    }

    public void setSpotType(String spotType) {
        this.spotType = spotType;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }
}