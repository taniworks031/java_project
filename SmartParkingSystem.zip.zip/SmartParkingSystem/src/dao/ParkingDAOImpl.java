package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.ParkingSpot;
import model.Vehicle;
import util.DBConnection;

/**
 * Data Access Object Implementation.
 * Contains core JDBC logic executing database transactions.
 * Demonstrates: Polymorphism, Method Overriding, and Exception Handling.
 */
public class ParkingDAOImpl implements ParkingDAO {

    // ==========================================
    // 1. CREATE OPERATION (Park Vehicle)
    // ==========================================
    @Override
    public boolean parkVehicle(Vehicle vehicle) {
        Connection conn = DBConnection.getConnection();
        
        String insertVehicleSQL = "INSERT INTO vehicles (vehicle_number, vehicle_type, owner_name, allocated_spot_id) VALUES (?, ?, ?, ?)";
        String updateSpotSQL = "UPDATE parking_spots SET is_available = FALSE WHERE spot_id = ?";
        
        PreparedStatement vehicleStmt = null;
        PreparedStatement spotStmt = null;
        
        try {
            // Disable auto-commit to handle these two updates as a single safe Transaction
            conn.setAutoCommit(false);

            // Step A: Insert the vehicle details
            vehicleStmt = conn.prepareStatement(insertVehicleSQL);
            vehicleStmt.setString(1, vehicle.getVehicleNumber());
            vehicleStmt.setString(2, vehicle.getVehicleType());
            vehicleStmt.setString(3, vehicle.getOwnerName());
            vehicleStmt.setInt(4, vehicle.getAllocatedSpotId());
            int vehicleInserted = vehicleStmt.executeUpdate();

            // Step B: Mark that specific parking slot as unavailable
            spotStmt = conn.prepareStatement(updateSpotSQL);
            spotStmt.setInt(1, vehicle.getAllocatedSpotId());
            int spotUpdated = spotStmt.executeUpdate();

            // If both updates succeeded, commit the transaction safely
            if (vehicleInserted > 0 && spotUpdated > 0) {
                conn.commit(); 
                return true;
            } else {
                conn.rollback(); // Undo changes if either statement fails
                return false;
            }
        } catch (SQLException e) {
            System.err.println("JDBC Error: Failed to complete vehicle check-in transaction sequence.");
            try { 
                if (conn != null) conn.rollback(); 
            } catch (SQLException ex) { 
                ex.printStackTrace(); 
            }
            e.printStackTrace();
            return false;
        } finally {
            // Clean up resources to prevent memory leaks
            try {
                if (vehicleStmt != null) vehicleStmt.close();
                if (spotStmt != null) spotStmt.close();
            } catch (SQLException e) { 
                e.printStackTrace(); 
            }
        }
    }

    // ==========================================
    // 2. READ OPERATION (View All Parked Vehicles)
    // ==========================================
    @Override
    public List<Vehicle> getAllParkedVehicles() {
        List<Vehicle> vehicleList = new ArrayList<>();
        String querySQL = "SELECT * FROM vehicles";
        
        // Using try-with-resources to automatically close connections and statements
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(querySQL);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Vehicle v = new Vehicle();
                v.setVehicleId(rs.getInt("vehicle_id"));
                v.setVehicleNumber(rs.getString("vehicle_number"));
                v.setVehicleType(rs.getString("vehicle_type"));
                v.setOwnerName(rs.getString("owner_name"));
                v.setAllocatedSpotId(rs.getInt("allocated_spot_id"));
                v.setEntryTime(rs.getTimestamp("entry_time"));
                
                vehicleList.add(v); // Hydrate individual rows into our object list collection
            }
        } catch (SQLException e) {
            System.err.println("JDBC Error: Failed to fetch active vehicle registry logs.");
            e.printStackTrace();
        }
        return vehicleList;
    }

    // ==========================================
    // 3. UPDATE OPERATION (Modify Log Entry Owner)
    // ==========================================
    @Override
    public boolean updateVehicleOwner(String vehicleNumber, String newOwner) {
        String updateSQL = "UPDATE vehicles SET owner_name = ? WHERE vehicle_number = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(updateSQL)) {
            
            stmt.setString(1, newOwner);
            stmt.setString(2, vehicleNumber);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Returns true if the record matches and updates successfully
        } catch (SQLException e) {
            System.err.println("JDBC Error: Failed to update vehicle registration record values.");
            e.printStackTrace();
            return false;
        }
    }

    // ==========================================
    // 4. DELETE OPERATION (Unpark / Release Spot)
    // ==========================================
    @Override
    public boolean unparkVehicle(String vehicleNumber) {
        Connection conn = DBConnection.getConnection();
        
        String selectSpotSQL = "SELECT allocated_spot_id FROM vehicles WHERE vehicle_number = ?";
        String deleteVehicleSQL = "DELETE FROM vehicles WHERE vehicle_number = ?";
        String updateSpotSQL = "UPDATE parking_spots SET is_available = TRUE WHERE spot_id = ?";
        
        PreparedStatement findStmt = null;
        PreparedStatement deleteStmt = null;
        PreparedStatement spotStmt = null;
        ResultSet rs = null;
        
        try {
            conn.setAutoCommit(false); // Enable strict manual transaction state handling
            
            // Step A: Find out which slot the vehicle is currently occupying
            findStmt = conn.prepareStatement(selectSpotSQL);
            findStmt.setString(1, vehicleNumber);
            rs = findStmt.executeQuery();
            
            if (rs.next()) {
                int occupiedSpotId = rs.getInt("allocated_spot_id");
                
                // Step B: Remove the vehicle record from the system database
                deleteStmt = conn.prepareStatement(deleteVehicleSQL);
                deleteStmt.setString(1, vehicleNumber);
                deleteStmt.executeUpdate();
                
                // Step C: Change the status flag of that parking spot back to Available (TRUE)
                spotStmt = conn.prepareStatement(updateSpotSQL);
                spotStmt.setInt(1, occupiedSpotId);
                spotStmt.executeUpdate();
                
                conn.commit(); // Save the transaction permanently
                return true;
            }
            conn.rollback(); // Rollback changes if the registration number doesn't match an active record
            return false;
        } catch (SQLException e) {
            System.err.println("JDBC Error: An issue occurred processing the checkout sequence.");
            try { 
                if (conn != null) conn.rollback(); 
            } catch (SQLException ex) { 
                ex.printStackTrace(); 
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (findStmt != null) findStmt.close();
                if (deleteStmt != null) deleteStmt.close();
                if (spotStmt != null) spotStmt.close();
            } catch (SQLException e) { 
                e.printStackTrace(); 
            }
        }
    }

    // ==========================================
    // 5. HELPER CORE READ METHOD (Get Vacant Slots)
    // ==========================================
    @Override
    public List<ParkingSpot> getAvailableSpots() {
        List<ParkingSpot> availableSpotsList = new ArrayList<>();
        String filterSQL = "SELECT * FROM parking_spots WHERE is_available = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(filterSQL);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                availableSpotsList.add(new ParkingSpot(
                    rs.getInt("spot_id"),
                    rs.getString("spot_number"),
                    rs.getString("spot_type"),
                    rs.getBoolean("is_available")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return availableSpotsList;
    }
}