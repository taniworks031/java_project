package dao;

import java.util.List;
import model.Vehicle;
import model.ParkingSpot;

/**
 * Interface ParkingDAO
 * Establishes the standard abstract CRUD operational definitions.
 * Demonstrates: OOP Abstraction principles.
 */
public interface ParkingDAO {
    
    // ==========================================
    // CORE CRUD OPERATION METHOD SIGNATURES
    // ==========================================

    /**
     * CREATE Operation
     * Registers a new incoming vehicle into the system database.
     * @param vehicle The domain entity object container.
     * @return true if database execution is successful, false otherwise.
     */
    boolean parkVehicle(Vehicle vehicle);

    /**
     * READ Operation
     * Fetches all active vehicles currently parked in the facility.
     * @return A List populated with encapsulated Vehicle instances.
     */
    List<Vehicle> getAllParkedVehicles();

    /**
     * UPDATE Operation
     * Modifies the recorded owner name logs for a specific registration plate ID.
     * @param vehicleNumber The unique string identifier for the target vehicle.
     * @param newOwner The updated name string to be committed.
     * @return true if records were modified, false if the vehicle wasn't found.
     */
    boolean updateVehicleOwner(String vehicleNumber, String newOwner);

    /**
     * DELETE Operation
     * Processes check-out routines and clears vehicle records from the tracking matrix.
     * @param vehicleNumber The unique target tracking identifier string.
     * @return true if deletion and spot release succeeds, false otherwise.
     */
    boolean unparkVehicle(String vehicleNumber);


    // ==========================================
    // UTILITY HELPER METHODS
    // ==========================================

    /**
     * Helper Query Operation
     * Pulls list of all available spots that have is_available flags set to TRUE.
     * Used to display structural map layouts to users before saving logs.
     * @return A List filled with structural ParkingSpot definitions.
     */
    List<ParkingSpot> getAvailableSpots();
}