package main;

import dao.ParkingDAO;
import dao.ParkingDAOImpl;
import java.util.List;
import java.util.Scanner;
import model.ParkingSpot;
import model.Vehicle;

/**
 * Main Application Console User Interface.
 * Orchestrates application control flow and handles user data entry parsing.
 * Demonstrates: Robust console validation, Menu System loops, and Separation of Concerns.
 */
public class Main {
    public static void main(String[] args) {
        // Instantiate the Data Access Object engine via Polymorphism
        ParkingDAO dao = new ParkingDAOImpl();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("==================================================");
        System.out.println("   WELCOME TO THE SMART PARKING ECOSYSTEM ENGINE  ");
        System.out.println("==================================================");

        // Continuous application runtime processing loop
        while (true) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Park New Vehicle (CREATE)");
            System.out.println("2. View All Parked Vehicles (READ)");
            System.out.println("3. Update Vehicle Owner Name (UPDATE)");
            System.out.println("4. Unpark Vehicle / Check-Out (DELETE)");
            System.out.println("5. Exit Ecosystem Application Runtime");
            System.out.print("\nEnter Choice: ");
            
            int selectedChoice;
            try {
                // Read input as a string and parse it to prevent scanner newline issues
                selectedChoice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("⚠️ Validation Error: Please input a valid selection integer number.");
                continue;
            }

            switch (selectedChoice) {
                case 1:
                    System.out.println("\n--- [OPERATION: CREATE] PARK VEHICLE ---");
                    
                    // Fetch real-time available spots from the database
                    List<ParkingSpot> dynamicAvailableSpots = dao.getAvailableSpots();
                    if (dynamicAvailableSpots.isEmpty()) {
                        System.out.println("❌ Facilities Management Alert: No parking vacancies available.");
                        break;
                    }
                    
                    // Display active layout matrix grid indices to the operator
                    System.out.println("Available Physical Parking Slots inside Database Matrix:");
                    System.out.printf("%-10s | %-15s | %-12s\n", "Spot ID", "Slot Code", "Category Type");
                    System.out.println("----------------------------------------------");
                    for (ParkingSpot spot : dynamicAvailableSpots) {
                        System.out.printf("%-10d | %-15s | %-12s\n", 
                            spot.getSpotId(), spot.getSpotNumber(), spot.getSpotType());
                    }
                    
                    System.out.print("\nEnter Target Spot ID to Allocate: ");
                    int chosenSpotId;
                    try {
                        chosenSpotId = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("⚠️ Validation Error: Invalid Spot ID formatting constraint.");
                        break;
                    }
                    
                    System.out.print("Enter License Plate Registration Number (e.g., MH-12-AB-1234): ");
                    String regNum = scanner.nextLine().trim();
                    if (regNum.isEmpty()) {
                        System.out.println("⚠️ Validation Error: Registration index values cannot be blank.");
                        break;
                    }

                    System.out.print("Enter Classification Class (Compact/Large/EV): ");
                    String classification = scanner.nextLine().trim();
                    
                    System.out.print("Enter Owner Identity Full Legal Name: ");
                    String legalName = scanner.nextLine().trim();

                    // Encapsulate raw input details inside our unified structural Domain Object model
                    Vehicle incomingVehicle = new Vehicle(regNum, classification, legalName, chosenSpotId);
                    
                    // Pass the model down to the database access layer
                    if (dao.parkVehicle(incomingVehicle)) {
                        System.out.println("🎉 SUCCESS: Vehicle allocation logged. Spot locked successfully.");
                    } else {
                        System.out.println("❌ FAILURE: Database execution dropped. Spot assignment validation failed.");
                    }
                    break;

                case 2:
                    System.out.println("\n--- [OPERATION: READ] ACTIVE VEHICLE LOGS ---");
                    List<Vehicle> activeFleetRegistry = dao.getAllParkedVehicles();
                    
                    if (activeFleetRegistry.isEmpty()) {
                        System.out.println("ℹ️ System State: No tracked vehicles found in active memory registries.");
                    } else {
                        System.out.printf("%-6s | %-16s | %-12s | %-18s | %-20s\n", 
                            "Log ID", "Plate Number", "Class Type", "Owner Name", "Entry Log Timestamp");
                        System.out.println("-----------------------------------------------------------------------------------------");
                        for (Vehicle current : activeFleetRegistry) {
                            System.out.printf("%-6d | %-16s | %-12s | %-18s | %-20s\n", 
                                current.getVehicleId(), current.getVehicleNumber(), current.getVehicleType(), 
                                current.getOwnerName(), current.getEntryTime());
                        }
                    }
                    break;

                case 3:
                    System.out.println("\n--- [OPERATION: UPDATE] MODIFY VEHICLE OWNER LOG ---");
                    System.out.print("Enter Target Vehicle License Plate Registration: ");
                    String targetPlates = scanner.nextLine().trim();
                    
                    System.out.print("Enter Updated Full Legal Owner Name: ");
                    String operationalNewOwner = scanner.nextLine().trim();
                    
                    if (dao.updateVehicleOwner(targetPlates, operationalNewOwner)) {
                        System.out.println("🎉 SUCCESS: Operational modification committed to tracking logs.");
                    } else {
                        System.out.println("❌ FAILURE: Record Query Mismatch. Registration string not matched in logs.");
                    }
                    break;

                case 4:
                    System.out.println("\n--- [OPERATION: DELETE] CHECK-OUT RUNTIME PIPELINE ---");
                    System.out.print("Enter Departure License Plate String: ");
                    String outboundPlates = scanner.nextLine().trim();
                    
                    if (dao.unparkVehicle(outboundPlates)) {
                        System.out.println("🎉 SUCCESS: Clearance granted. Spot flag returned to vacant state.");
                    } else {
                        System.out.println("❌ FAILURE: Process Refused. Vehicle target reference not tracked in logs.");
                    }
                    break;

                case 5:
                    System.out.println("\n==================================================");
                    System.out.println(" Closing database connections. Application closing safely.");
                    System.out.println("==================================================");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("⚠️ Menu Error: Choice out of scope range boundaries. Try again.");
            }
        }
    }
}