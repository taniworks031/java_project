package main;

import java.sql.Connection;
import util.DBConnection;

public class TestConnection {
    public static void main(String[] args) {
        System.out.println("Initiating handshake connection sequence to local MySQL database...");
        
        // Attempt to capture the initialized database link from your new utility
        Connection conn = DBConnection.getConnection();
        
        if (conn != null) {
            System.out.println("\n=============================================");
            System.out.println("🎉 SUCCESS: Java successfully connected to MySQL!");
            System.out.println("=============================================");
        } else {
            System.out.println("\n=============================================");
            System.out.println("❌ FAILURE: Connection returned null. Review errors above.");
            System.out.println("=============================================");
        }
    }
}