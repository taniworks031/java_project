package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database Connection Utility.
 * Uses the Singleton design pattern to manage a single active database connection.
 * Demonstrates: Encapsulation and robust Exception Handling.
 */
public class DBConnection {
    // Port 3306 is the default port for MySQL. Change it if your installation uses a custom port.
    private static final String URL = "jdbc:mysql://localhost:3306/smart_parking_db";
    private static final String USERNAME = "root"; 
    
    // ⚠️ CRITICAL VIVA STEP: Change "your_password" to your actual local MySQL root password!
    private static final String PASSWORD = "Mymysql13*"; 

    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            // Check if connection doesn't exist yet, or if it was closed by a database timeout
            if (connection == null || connection.isClosed()) {
                // Explicitly load the driver class for legacy academic environment compatibility
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                // Establish the handshake bridge to the database server
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            }
        } catch (ClassNotFoundException e) {
            System.err.println("❌ JDBC Connection Error: MySQL Driver class not found! Ensure the JAR is in your lib folder.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("❌ JDBC Connection Error: Failed to log into the MySQL database instance.");
            System.err.println("👉 CHECKLIST: Is your MySQL server running? Is your password correct? Does 'smart_parking_db' exist?");
            e.printStackTrace();
        }
        return connection;
    }
}